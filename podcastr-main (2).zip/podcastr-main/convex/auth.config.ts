const authConfig = {
  providers: [
    {
      domain: "https://fond-sawfly-54.clerk.accounts.dev",
      applicationID: "convex",
    },
  ]
};

export default authConfig;